#include <iostream>
using namespace std;
class ABC
{
    public: 
    
      int year,flag=0;
    void leap()
    {
    cout<<"enter the year";
    cin>>year;
    while(flag>=0 && flag<13)
    {
     if (((year % 4 == 0) && (year % 100!= 0)) || (year%400 == 0))
     {
         cout<<"leap year is:   "<<year; 
         year=year+4;
         flag=flag+1;
     }
     else
     {
         year=year+1;
     }
    }
}
};
int main()
{
  ABC dip;
  dip.leap();
  return 0;
  //2028, 2032, 2036, 2040, 2044
}

