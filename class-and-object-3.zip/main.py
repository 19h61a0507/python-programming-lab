class store:
     def __init__(self,name,date,month,year):
         self.name=name
         self.date=date
         self.month=month
         self.year=year
         
     def display(self):
        print("Name: ",self.name)
        print("Date of Birth: ",self.date,"/",self.month,"/",self.year)
        
     def decide(self):
        if(self.year<=2002):
            print("Eligible to vote")
        else:
            print("Not Eligible to vote")


d1=store("Anirudh",3,5,2005)
d1.decide()
d1.display()
        
    
