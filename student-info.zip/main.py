class student:
    def __init__(self,name,rollno,marks):
        self.name=name
        self.rollno=rollno
        self.marks=marks
        
    total=0
    def count(self):
        for i in self.marks:
            self.total=self.total+i
        print("Total marks obtained = %d" %self.total)
            
    def display(self):
        
        print(self.name)   
        print(self.rollno)
        print(self.marks)
        
        
marks=[76.45,96.5,64]
q1=student("Steve jobs","12-A09E34",marks)
q1.display()
q1.count()
