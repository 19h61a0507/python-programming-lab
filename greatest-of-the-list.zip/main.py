class numbers:
    def __init__(self,num):
        self.num=num
        self.q=max(self.num)
        print("Greatest of all is %d" %self.q)
            
    
    
    
    
    
num=[10,2,54,89]
q1=numbers(num)
