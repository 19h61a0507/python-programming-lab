class student:
    def __init__(self,name):
        self.name=name
    def dis(self):
        print("name is " + self.name)
        
        
r1=student("Anirudh")
r1.dis()

