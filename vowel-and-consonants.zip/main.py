class string:
    def __init__(self,str1):
        self.str1=str1
    def findout(self):
        vowel=0
        cons=0
        for i in str1:
            if i=='a'||i=='e'||i='i'||i=='o'||i=='u':
                vowel+=1
            else:
                cons+=1
