class string:
    def __init__ (self, str1):
        self.str1 = str1 

    def findout (self):
        vowel = 0 
        cons = 0 
        for self.i in self.str1:
            if self.i == 'a' or self.i == 'e' or self.i == 'i' or self.i == 'o' or self.i == 'u':
                vowel +=1
            else:
                cons += 1
        print ("Number of Vowels = %d" % vowel)
        print ("Number of Consonants = %d" % cons)
    
    def upperorlower (self):
         upper = 0 
         lower = 0 
         for self.i in self.str1:
             if self.i.isupper ():
                 upper += 1
             else:
                 lower += 1 
         print("Number of Upper Case Characters = %d"%upper)
         print("Number of Lower Case Characters = %d"%lower)
         
                 
q1 = string ("AniruHh")
q1.findout ()
q1.upperorlower()
