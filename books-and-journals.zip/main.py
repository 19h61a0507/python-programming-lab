class books:
    def __init__(self,t_book,t_journal):
        self.t_book=t_book
        self.t_journal=t_journal
    
    def Book(self):
        self.needed=int(input("Enter the number of books needed  "))
        self.t_book=self.t_book-self.needed
        print("Total Number of Books are %d " %self.t_book)
        print("Total number of Books DUE are %d"%self.needed)
        
    def journals(self):
        self.need=int(input("Enter the number of jouranals needed  "))
        self.t_journal=self.t_journal-self.need
        print("Total Number of Books are %d " %self.t_journal)
        print("Total number of journals DUE are %d" %self.need)
        
select=['books','journals']
q1=books(600,765)
select=input("Enter what is needed?......BOOKS (OR) JOURNALS......")
q1.Book() 
q1.journals() 


    