class emp:
    empcount=0
    def __init__(self,name,desig,salary):
        self.name=name
        self.desig=desig
        self.salary=salary
        emp.empcount+=1
    def discount(self):
        print("Total employees are %d"%emp.empcount)
    def disdetails(self):
        print("Name: ",self.name,"Designation: ",self.desig,"Salary: ",self.salary)
        
        
e1=emp("Anirudh","CEO",1200000)
e1.disdetails()
e2=emp("Raj","Manager",90000)
e2.disdetails()
e3=emp("Shubham","Employee",60000)
e3.disdetails()
e3.discount()