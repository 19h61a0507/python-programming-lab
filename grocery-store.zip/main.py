class store:
    def __init__(self):
        items = [('diapers', 10.00), ('peanuts', 5.00), ('butter', 6.25), ('cheese', 3.00), ('milk', 3.5), ('yogurt', 1.99), ('eggs', 4.5)]
        select = ['buy','quit']
        cart=[]
        money=0
        select = input("Do you want to Buy or Quit")
        while select != 'quit':
                print("1.Diapers = Rs.10.00 \n 2.peanuts = Rs.5.00 \n 3.Butter = Rs.6.25 \n 4.Cheese = 3.00 \n 5.Milk = Rs.3.5 \n 6.Yogurt = Rs.1.99 \n 7.Eggs = 4.5 \n")
                item = input('\nWhat item do you need?\n')
                
                for a,b in items:
                    if a == item:
                        cart.append(item)
                        money += b
                        continue

                select = input("Do you want to Buy or Quit")
        print(cart)
        print("Total Amount = ",money)        
        print("Thank you for visiting\n\n")
        
        
        
d1=store()
                    
                        
                    
                        
                        
                
    



