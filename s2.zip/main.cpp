#include <iostream>
using namespace std;
class student
{
    public:
    
    int avg,total=0,a[8],i;
    void Student_Grade()
    {
    cout<<"enter the marks obtained in all the 6 subjects";
    for(i=1;i<7;i++)
    {
        cin>>a[i];
        total=total+a[i];
    }
    avg=total/6;
    cout<<"the total obtained is:-  "<<total<<"\n";
    cout<<"the avg obtained is  :-   "<<avg<<"\n";
    if(avg>90)
    {
        cout<<"DISTINCTION";
    }
    else if (avg>=60 && avg<70)
    {
        cout<<"FIRST CLASS";
    }
    else if(avg>=50 && avg<60)
    {
        cout<<"PASSED";
    }
    else if(avg<50)
    {
        cout<<"FAILED";
    }
}
};
int main()
{
    student s1;
    s1.Student_Grade();
    return 0;
    
}

