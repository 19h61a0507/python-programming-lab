#include <iostream>
using namespace std;
class Rev
{
    public:
    
    int num,rem,reverse=0,original;
    void Reverse_Num()
    {
  cout<<"enter the number";
    cin>>num;
       original=num;
        while (num != 0)
    {
        rem = num % 10;
        reverse = reverse * 10 + rem;
        num =num/ 10;
    }
    if(original==reverse)
    {
        cout<<"the entered number is palindrome";
    }
    else
    {
        cout<<"number isn't a palindrome";
    }
    }
};
int main()
{
    Rev number;
    number.Reverse_Num();
    return 0;
}