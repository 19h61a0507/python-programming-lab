class rectangle:
    def __init__(self,length,breadth):
        self.length=length
        self.breadth=breadth
        
    def area(self):
        a=self.length*self.breadth
        return a
        
d1=rectangle(12,10)
p=d1.area()
print("Area of Rectangle  : ", p )


    