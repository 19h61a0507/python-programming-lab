#include <iostream>
using namespace std;
class opt
{
    public:
    
    int num1,num2,choice;
    void Operators()
    {
    cout<<"SELECT CHOICE\n 1.addition\n2.subtraction\n3.multiplication\n4.division\n";
    cin>>choice;
    cout<<"enter the numbers you want to perform operation on??\n";
    cin>>num1>>num2;
    switch(choice)
    {
        case 1:
        {
            int sum;
            sum=num1+num2;
            cout<<"ADDITION :- " <<sum;
            break;
        }
        case 2:
        {
            int sub;
            sub=num1-num2;
            cout<<"subtraction :- "<<sub;
            break;
        }
        case 3:
        {
            int mul;
            mul=num1*num2;
            cout<<"MULTIPLICATION :-"<<mul;
            break;
        }
        case 4:
        {
            float d;
            d=num1/num2;
            cout<<"DIVISION :-"<<d;
            break;
        }
        default:
        {
            cout<<"entered choice is wrong";
        }
    }
    }
};
int main()
{
  opt o;
  o.Operators();
}
    
