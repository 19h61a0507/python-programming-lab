class circle:
    
    def __init__(self,radius):
        pi=3.14
        circumference=2*pi*radius
        area=pi*radius*radius
        print("circumference : ",circumference)
        print("Area : ",area)
        
        
        
d1=circle(5)