class bank:
    def __init__(self,amount):
        self.amount=amount
    def deposit(self):
        self.dep=int(input("Enter the amount you want to deposit     "))
        self.amount=self.amount+self.dep
        print("Bank Balance :-  %d" %self.amount)
    def withdrawal(self):
        self.amount2=int(input("Enter the amount you want to withdraw   "))
        self.amount=self.amount-self.amount2
        print("Bank Balance :-  %d" %self.amount)
        
        
        
q1=bank(20000)
bankk=['deposit','withdrawal']
choice=input("Deposit or Withdrawal?........Select one and type it ")
c1=1
while c1:
    if choice=='deposit':
        q1.deposit()
        c1=int(input("press 0 to exit else press any other number"))
    else:
        q1.withdrawal()
        c1=int(input("press 0 to exit else press any other number"))
        
    


    
